import{_ as e,V as t,W as _}from"./framework-c2e81092.js";const c={};function r(n,o){return t(),_("div")}const a=e(c,[["render",r],["__file","404.html.vue"]]);export{a as default};

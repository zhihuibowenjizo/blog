import{_ as e,V as t,W as c}from"./framework-c2e81092.js";const n={};function _(r,o){return t(),c("div")}const a=e(n,[["render",_],["__file","index.html.vue"]]);export{a as default};
